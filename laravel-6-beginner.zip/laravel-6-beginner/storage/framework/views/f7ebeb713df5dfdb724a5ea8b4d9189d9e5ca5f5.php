

<?php $__env->startSection('title','About Us page'); ?>


<?php $__env->startSection('content'); ?>
<h1>Welcome to laravel from about</h1>
<p>With some additional information</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Apurva\Documents\laravel-6-beginner\resources\views/about.blade.php ENDPATH**/ ?>