<h1>Customers</h1>

<a href="<?php echo e(url('/customers/create')); ?>">Add new customer</a>

<?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <p><strong>
   <a href="/customers/<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></a>
   <br>
   </strong><?php echo e($customer->email); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No customers to show.</p>
<?php endif; ?>
<?php /**PATH C:\Users\Apurva\Documents\laravel-6-beginner\resources\views/customer/index.blade.php ENDPATH**/ ?>