<h1>Customer details</h1>

<a href="/customers">Go Back</a><br>
<strong>Name</strong>
<p><?php echo e($customer->name); ?></p>

<strong>Email</strong>
<p><?php echo e($customer->email); ?></p>

<div>
<a href="/customers/<?php echo e($customer->id); ?>/edit">Edit</a>

<form action="/customers/<?php echo e($customer->id); ?>" method="post">
<?php echo method_field('DELETE'); ?>
<?php echo csrf_field(); ?>
<button>Delete</button>
</div><?php /**PATH C:\Users\Apurva\Documents\laravel-6-beginner\resources\views/customer/show.blade.php ENDPATH**/ ?>