<h1>Edit Customer details</h1>

<form action="/customers/<?php echo e($customer->id); ?>" method="post">
<?php echo method_field('PATCH'); ?>
<div>
<label for="name">Name</label>
<input type="text" name="name" autocomplete="off" value="<?php echo e($customer->name); ?>">
<p style="color:red;"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<div>
<label for="email">Email</label>
<input type="text" name="email" autocomplete="off" value="<?php echo e($customer->email); ?>"> 
<p style="color:red;"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
</div>
<?php echo csrf_field(); ?>
<button>Save Customer</button>
<form><?php /**PATH C:\Users\Apurva\Documents\laravel-6-beginner\resources\views/customer/edit.blade.php ENDPATH**/ ?>