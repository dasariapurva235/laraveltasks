<ul>
    <li><a href='/about'></a>About us</li>
    <li><a href='/service'></a>Services</li>
</ul><?php /**PATH C:\Users\Apurva\Documents\laravel-6-beginner\resources\views/nav.blade.php ENDPATH**/ ?>