<h1>Hello hello</h1>
<h1><?php echo e($coolString); ?></h1>
<?php /**PATH C:\Users\Apurva\Documents\laravel-6-beginner\resources\views/hello.blade.php ENDPATH**/ ?>