@extends('app')

@section('title','About Us page')


@section('content')
<h1>Welcome to laravel from about</h1>
<p>With some additional information</p>
@endsection
