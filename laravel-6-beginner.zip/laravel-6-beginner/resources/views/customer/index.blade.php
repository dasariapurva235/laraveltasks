<h1>Customers</h1>

<a href="{{url('/customers/create')}}">Add new customer</a>

@forelse($customers as $customer)
   <p><strong>
   <a href="/customers/{{$customer->id}}">{{ $customer->name }}</a>
   <br>
   </strong>{{ $customer->email }}</p>
@empty
    <p>No customers to show.</p>
@endforelse
