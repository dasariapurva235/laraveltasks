<ul>
    <li><a href='/about'></a>About us</li>
    <li><a href='/service'></a>Services</li>
</ul>